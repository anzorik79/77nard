// game.js — demo board with dice & simple moves (not full rules)
(function(){
  const canvas = document.getElementById('board');
  const ctx = canvas.getContext('2d');
  const rollBtn = document.getElementById('rollDice');
  const diceOut = document.getElementById('diceResult');

  const imgBoard = new Image();
  imgBoard.src = 'assets/board.png';

  const imgLight = new Image();
  imgLight.src = 'assets/checker_light.png';
  const imgDark = new Image();
  imgDark.src = 'assets/checker_dark.png';

  // Simple points geometry (24 triangles), positions projected to canvas
  const points = [];
  const W = canvas.width, H = canvas.height;
  const margin = 40;
  const mid = W/2;
  const topY = margin, botY = H - margin;
  const colW = (W - margin*2) / 12;

  // upper row: 12..1 left->right visually, but we'll store 0..23
  for(let i=0;i<12;i++){
    points.push({x: margin + i*colW + colW/2, y: topY+20, stack:[]}); // 0..11 top row
  }
  // bottom row: 13..24 right->left visually
  for(let i=0;i<12;i++){
    points.push({x: margin + (11-i)*colW + colW/2, y: botY-20, stack:[]}); // 12..23 bottom row
  }

  // initial simplified setup (not exact long backgammon, demo only)
  function placeInitial(){
    for(const p of points) p.stack = [];
    // light
    points[0].stack = new Array(2).fill('L');     // demo
    points[5].stack = new Array(5).fill('L');
    points[7].stack = new Array(3).fill('L');
    points[11].stack = new Array(5).fill('L');
    // dark
    points[12].stack = new Array(2).fill('D');
    points[16].stack = new Array(5).fill('D');
    points[18].stack = new Array(3).fill('D');
    points[23].stack = new Array(5).fill('D');
  }

  function drawBoard(){
    ctx.clearRect(0,0,W,H);
    // Board bg
    ctx.drawImage(imgBoard, 0, 0, W, H);

    // Triangles (visual only)
    ctx.save();
    for(let i=0;i<12;i++){
      // top
      ctx.beginPath();
      ctx.moveTo(margin + i*colW + colW*0.1, topY);
      ctx.lineTo(margin + (i+0.5)*colW, topY+120);
      ctx.lineTo(margin + (i+0.9)*colW, topY);
      ctx.closePath();
      ctx.globalAlpha = 0.15;
      ctx.fill();
      // bottom
      ctx.beginPath();
      ctx.moveTo(margin + i*colW + colW*0.1, botY);
      ctx.lineTo(margin + (i+0.5)*colW, botY-120);
      ctx.lineTo(margin + (i+0.9)*colW, botY);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();

    // Checkers
    const radius = 22;
    for(let i=0;i<24;i++){
      const p = points[i];
      const up = i<12;
      const stack = p.stack;
      for(let s=0; s<stack.length; s++){
        const isLight = stack[s]==='L';
        const img = isLight ? imgLight : imgDark;
        const yy = up ? (p.y + s*(radius*1.2)) : (p.y - s*(radius*1.2));
        ctx.drawImage(img, p.x - radius, yy - radius, radius*2, radius*2);
      }
    }

    // dragging ghost
    if(drag.active && drag.img){
      ctx.globalAlpha = 0.9;
      ctx.drawImage(drag.img, drag.x - drag.r, drag.y - drag.r, drag.r*2, drag.r*2);
      ctx.globalAlpha = 1;
    }
  }

  function rollDice(){
    const d1 = 1 + Math.floor(Math.random()*6);
    const d2 = 1 + Math.floor(Math.random()*6);
    diceOut.textContent = d1 + ' + ' + d2 + (d1===d2 ? ' (дубль)' : '');
    // store last dice (for demo — no full rule validation)
    lastDice = [d1,d2];
  }

  let lastDice = [null,null];
  const drag = {active:false, from:null, color:null, img:null, x:0, y:0, r:22};

  function hitTest(x,y){
    // return {pointIndex, stackIndex}
    const r = drag.r;
    for(let i=0;i<24;i++){
      const p = points[i];
      const up = i<12;
      const stack = p.stack;
      for(let s=stack.length-1; s>=0; s--){
        const yy = up ? (p.y + s*(r*1.2)) : (p.y - s*(r*1.2));
        const dx = x - p.x, dy = y - yy;
        if(Math.sqrt(dx*dx+dy*dy) <= r) return {i, s};
      }
    }
    return null;
  }

  canvas.addEventListener('mousedown', (e)=>{
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const h = hitTest(x,y);
    if(!h) return;
    const piece = points[h.i].stack[h.s];
    drag.active = true;
    drag.from = h.i;
    drag.color = piece;
    drag.img = (piece==='L') ? imgLight : imgDark;
    drag.x = x; drag.y = y;
    points[h.i].stack.splice(h.s,1);
    drawBoard();
  });

  canvas.addEventListener('mousemove', (e)=>{
    if(!drag.active) return;
    const rect = canvas.getBoundingClientRect();
    drag.x = e.clientX - rect.left;
    drag.y = e.clientY - rect.top;
    drawBoard();
  });

  canvas.addEventListener('mouseup', (e)=>{
    if(!drag.active) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // find nearest point
    let best = {i:0, d:1e9};
    for(let i=0;i<24;i++){
      const p = points[i];
      const dx = x - p.x, dy = y - p.y;
      const d = dx*dx+dy*dy;
      if(d < best.d){ best = {i, d}; }
    }
    // Drop piece to best.i (no full rule validation in demo)
    points[best.i].stack.push(drag.color);
    drag.active = false; drag.img = null;
    drawBoard();
  });

  imgBoard.onload = ()=>{ placeInitial(); drawBoard(); }
  imgLight.onload = ()=> drawBoard();
  imgDark.onload = ()=> drawBoard();

  rollBtn.addEventListener('click', rollDice);
})();