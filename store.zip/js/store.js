// store.js — demo store
(function(){
  const list = document.getElementById('storeList');
  const items = [
    { id:'skin_gold', title:'Золотой набор', price:'499 ★', img:'assets/store_gold.jpg' },
    { id:'skin_carbon', title:'Carbon-пак', price:'299 ★', img:'assets/store_carbon.jpg' },
    { id:'skin_classic', title:'Classic set', price:'99 ★', img:'assets/store_classic.jpg' }
  ];

  function render(){
    list.innerHTML = items.map(it => `
      <div class="card">
        <img src="${it.img}" alt="${it.title}">
        <div class="title">${it.title}</div>
        <div class="price">${it.price}</div>
        <button data-id="${it.id}" class="primary">Купить</button>
      </div>
    `).join('');
    list.querySelectorAll('button').forEach(b=>{
      b.addEventListener('click', (e)=>{
        const id = e.target.getAttribute('data-id');
        alert('Покупка (демо): ' + id);
      });
    });
  }
  render();
})();