// leaderboard.js — demo static table
(function(){
  const body = document.getElementById('lbBody');
  const rows = [
    { name:'PlayerOne', w:120, r:2540 },
    { name:'GamerUA',  w:98,  r:2310 },
    { name:'ProMax',   w:76,  r:1995 },
    { name:'Vlad',     w:52,  r:1750 },
    { name:'Daria',    w:40,  r:1605 },
  ];
  function render(){
    body.innerHTML = rows.map((r,i)=>`<tr>
      <td>${i+1}</td><td>${r.name}</td><td>${r.w}</td><td>${r.r}</td>
    </tr>`).join('');
  }
  render();
})();