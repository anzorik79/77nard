// auth.js — demo auth
(function(){
  const tg = window.Telegram && window.Telegram.WebApp ? window.Telegram.WebApp : null;
  const viewAuth = document.getElementById('view-auth');
  const viewGame = document.getElementById('view-game');
  const viewStore = document.getElementById('view-store');
  const viewLb = document.getElementById('view-leaderboard');

  const btnGame = document.getElementById('btnGame');
  const btnStore = document.getElementById('btnStore');
  const btnLeaderboard = document.getElementById('btnLeaderboard');
  const btnLogout = document.getElementById('btnLogout');

  function show(id){
    [viewAuth, viewGame, viewStore, viewLb].forEach(v=>v.classList.remove('visible'));
    id.classList.add('visible');
  }

  // Telegram auto-auth (demo)
  const authHint = document.getElementById('authHint');
  if(tg && tg.initDataUnsafe && tg.initDataUnsafe.user){
    const u = tg.initDataUnsafe.user;
    localStorage.setItem('user', JSON.stringify({ id: u.id, name: u.username || (u.first_name || 'Player') }));
    authHint.textContent = 'Вход через Telegram ✓';
    show(viewGame);
  } else {
    const saved = localStorage.getItem('user');
    if(saved){
      authHint.textContent = 'Вход сохранён ✓';
      show(viewGame);
    }
  }

  document.getElementById('authForm').addEventListener('submit', (e)=>{
    e.preventDefault();
    const login = document.getElementById('login').value.trim();
    const password = document.getElementById('password').value.trim();
    if(login.length<2 || password.length<2){
      authHint.textContent = 'Ошибка: короткий логин/пароль';
      return;
    }
    localStorage.setItem('user', JSON.stringify({ id: Date.now(), name: login }));
    authHint.textContent = 'Вход выполнен ✓';
    show(viewGame);
  });

  btnGame.addEventListener('click', ()=>show(viewGame));
  btnStore.addEventListener('click', ()=>show(viewStore));
  btnLeaderboard.addEventListener('click', ()=>show(viewLb));
  btnLogout.addEventListener('click', ()=>{
    localStorage.removeItem('user');
    show(viewAuth);
  });
})();